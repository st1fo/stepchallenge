import assert from 'node:assert/strict';
import {spawn} from 'node:child_process';
import {readFile,mkdtemp,rm} from 'node:fs/promises';
import os from 'node:os';
import path from 'node:path';
const origin='http://127.0.0.1:3107';
const adminEmail='admin@step.local',adminPassword=crypto.randomUUID()+crypto.randomUUID(),ocrToken=crypto.randomUUID();
const dataDir=await mkdtemp(path.join(os.tmpdir(),'step-linux-test-'));
let app,ocr;
async function stop(child){if(!child||child.exitCode!==null)return;await new Promise(resolve=>{child.once('exit',resolve);child.kill('SIGTERM');});}
async function ready(url){for(let i=0;i<200;i++){try{if((await fetch(url)).ok)return;}catch{}await new Promise(r=>setTimeout(r,100));}throw new Error('Service did not start: '+url);}
function launchApp(){const child=spawn(process.execPath,['.next/standalone/server.js'],{env:{...process.env,PORT:'3107',HOSTNAME:'127.0.0.1',APP_ORIGIN:origin,DATA_DIR:dataDir,ADMIN_EMAIL:adminEmail,ADMIN_PASSWORD:adminPassword,OCR_SERVICE_URL:'http://127.0.0.1:8107/ocr',OCR_SERVICE_TOKEN:ocrToken,NODE_ENV:'production'},stdio:['ignore','pipe','pipe']});child.stderr.on('data',d=>process.stderr.write(d));return child;}
const request=(url,init)=>fetch(url,init);
try{
ocr=spawn(process.env.OCR_PYTHON||'python3',['-m','uvicorn','server:app','--app-dir','ocr-service','--host','127.0.0.1','--port','8107'],{env:{...process.env,OCR_SERVICE_TOKEN:ocrToken},stdio:['ignore','pipe','pipe']});
ocr.stderr.on('data',d=>process.stderr.write(d));
await ready('http://127.0.0.1:8107/health');
app=launchApp();await ready(origin+'/api/health');
let cookie='',other='',admin='';let checks=0;
async function call(path,body,who=cookie){const r=await request(origin+'/api/'+path,{method:body===undefined?'GET':'POST',headers:{Origin:origin,...(body instanceof FormData?{}:{'Content-Type':'application/json'}),Cookie:who},body:body===undefined?undefined:body instanceof FormData?body:JSON.stringify(body)});let d;try{d=await r.json()}catch{d={}}return {status:r.status,d,cookie:r.headers.get('set-cookie')?.split(';')[0]};}
function ok(condition,label){assert.ok(condition,label);checks++;console.log('PASS',label);}
const email='test-'+Date.now()+'@example.com',password='test-'+crypto.randomUUID();
let r=await call('auth/register',{email,password,name:'Integration Walker'});ok(r.status===200,'Register user');cookie=r.cookie;
r=await call('state');ok(r.status===200&&r.d.leaders.length===2&&r.d.leaders.every(x=>!x.is_demo),'Clean initialization without fictional participants');
r=await call('auth/login',{email,password});ok(r.status===200,'Login with password');cookie=r.cookie;
r=await call('auth/register',{email:'other-'+Date.now()+'@example.com',password,name:'Other Walker'});other=r.cookie;
r=await call('auth/login',{email:adminEmail,password:adminPassword});ok(r.status===200,'Local administrator login');admin=r.cookie;
const image=await readFile('tests/step-screenshot.png');
async function upload(bytes,who=cookie){const form=new FormData();form.set('file',new Blob([bytes],{type:'image/png'}),'steps.png');return call('upload',form,who);}
r=await upload(image);ok(r.status===200,'Screenshot stored privately');const uploadId=r.d.uploadId;console.log('OCR result:',r.d);
ok(r.d.trusted&&r.d.steps===14382&&r.d.date==='2026-10-01','Actual server Tesseract reads steps and date');
let a=await request(origin+'/api/screenshot/'+uploadId,{headers:{Cookie:cookie}});ok(a.status===200,'Owner can inspect screenshot');a=await request(origin+'/api/screenshot/'+uploadId,{headers:{Cookie:other}});ok(a.status===404,'Other users cannot inspect screenshot');
r=await upload(image);ok(r.status===200&&r.d.resumed&&r.d.uploadId===uploadId,'Interrupted upload safely resumes without adding duplicates');
r=await call('entries',{uploadId,date:'2026-11-01',steps:14382});ok(r.status===400,'Out-of-challenge date rejected');
r=await call('entries',{uploadId,date:'2026-10-01',steps:1.5});ok(r.status===400,'Non-integer steps rejected');
r=await call('entries',{uploadId,date:'2026-10-01',steps:14382});ok(r.status===200&&r.d.status==='verified','Confirm and save trusted OCR');
r=await upload(image);ok(r.status===409,'Identical submitted screenshot is prevented');
r=await call('state');const uid=r.d.user.id;ok(r.d.leaders.find(u=>u.id===uid).total===14382,'Leaderboard immediately uses stored steps');
r=await call('entries',{uploadId,date:'2026-10-01',steps:14382});ok(r.status===409,'Duplicate date/entry prevented');
r=await call('admin',undefined,cookie);ok(r.status===403,'Admin authorization enforced');
r=await call('admin',undefined,admin);const entry=r.d.submissions.find(x=>x.user_id===uid);ok(!!entry&&entry.detected_steps===14382,'Admin sees original OCR and final value');
a=await request(origin+'/api/screenshot/'+uploadId,{headers:{Cookie:admin}});ok(a.status===200,'Admin can inspect screenshot');
r=await call('admin/submission',{id:entry.id,date:entry.date,steps:12000,status:'verified',reason:'Corrected from original screenshot'},admin);ok(r.status===200,'Admin edits submission');
r=await call('state');ok(r.d.leaders.find(u=>u.id===uid).total===12000,'Admin edit recalculates leaderboard');
r=await call('admin/submission',{id:entry.id,date:entry.date,steps:12000,status:'rejected',reason:'Rejected integration fixture'},admin);ok(r.status===200,'Admin rejects submission');r=await call('state');ok(r.d.leaders.find(u=>u.id===uid).total===0,'Rejected steps excluded from totals');
r=await call('admin',undefined,admin);ok(r.d.audit.some(a=>a.entity_id===entry.id),'Admin changes create audit log');
r=await call('admin/purge',{confirm:'DELETE SCREENSHOTS'},admin);ok(r.status===400,'Retention purge protected until challenge ends');
a=await request(origin+'/api/entries',{method:'POST',headers:{Origin:'https://untrusted.invalid','Content-Type':'application/json',Cookie:cookie},body:'{}'});ok(a.status===403,'Cross-origin writes blocked');

r=await upload(Buffer.concat([image,Buffer.from('unique-test-fixture')]));const second=r.d.uploadId;ok(r.status===200,'Second screenshot uploads');
r=await call('entries',{uploadId:second,date:'2026-10-01',steps:70000});ok(r.status===409,'Different screenshot cannot bypass unique date');
r=await call('entries',{uploadId:second,date:'2026-10-02',steps:70000,detected_steps:70000,user_id:'demo-0',status:'verified'});ok(r.status===200&&r.d.status==='pending_review','High manual value saved but flagged; client status ignored');
r=await call('admin',undefined,admin);const flagged=r.d.submissions.find(x=>x.upload_id===second);ok(flagged.user_id===uid&&flagged.detected_steps===14382&&flagged.manually_modified===1,'User identity and original OCR cannot be forged');
r=await upload(Buffer.from('this is not an image'));ok(r.status===400,'Unsupported image rejected');
r=await upload(Buffer.alloc(9*1024*1024));ok(r.status===413,'Oversized upload rejected');
const loggedOut=await call('state',undefined,'');ok(loggedOut.status===401,'Authentication required');
r=await call('admin/remove-demo',{},admin);ok(r.status===200,'Admin can remove demo participants');r=await call('state');ok(r.d.leaders.every(x=>!x.is_demo),'Real competition excludes removed demos');

r=await upload(Buffer.from([137,80,78,71,0,0,0,0]));ok(r.status===400,'Forged PNG signature rejected');
a=await request(origin+'/data/challenge.sqlite');ok(a.status!==200||!String(a.headers.get('content-type')).includes('octet-stream'),'Database not publicly served');
for(const page of ['/login','/register','/dashboard','/leaderboard','/upload','/profile','/profile/'+uid,'/admin','/admin/submissions']){
 a=await request(origin+page);ok(a.status===200&&(await a.text()).includes('Telekom Step Challenge'),'Production route '+page);
}
await stop(app);app=launchApp();await ready(origin+'/api/health');
r=await call('state');ok(r.status===200&&r.d.user.id===uid&&r.d.history.length===2,'Database and sessions survive application restart');
a=await request(origin+'/api/screenshot/'+uploadId,{headers:{Cookie:cookie}});ok(a.status===200,'Screenshots survive application restart');
r=await call('auth/logout',{});ok(r.status===200,'Logout');r=await call('state');ok(r.status===401,'Logged-out session revoked');
console.log(`\n${checks} Linux production integration checks passed.`);
}finally{await stop(app);await stop(ocr);await rm(dataDir,{recursive:true,force:true});}
