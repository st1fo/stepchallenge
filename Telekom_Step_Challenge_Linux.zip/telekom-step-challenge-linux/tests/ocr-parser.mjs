import assert from 'node:assert/strict';
import {parseOCR} from '../lib/ocr.ts';
const count='\nTOTAL\n14,382\nsteps';
const cases=[['October 1, 2026','2026-10-01','explicit'],['THU, 1 OCT 2026','2026-10-01','explicit'],['1. októbra 2026','2026-10-01','explicit'],['1. října 2026','2026-10-01','explicit'],['1. Oktober 2026','2026-10-01','explicit'],['1. 10. 2026','2026-10-01','explicit'],['1.10.','2026-10-01','inferred_year'],['1 Oct','2026-10-01','inferred_year'],['Thu, 2026-10-01','2026-10-01','explicit'],['October 1–7, 2026',null,'ambiguous'],['1 Oct 2026\n2 Oct 2026',null,'ambiguous'],['Today',null,'missing'],['Dnes',null,'missing'],['Yesterday',null,'missing'],['10/01/2026',null,'missing'],['31. 11. 2026',null,'missing'],['29. 2. 2026',null,'missing'],['29. 2. 2024','2024-02-29','explicit']];
for(const [date,want,source] of cases){const result=parseOCR(date+count);assert.equal(result.date,want,date);assert.equal(result.dateSource,source,date);assert.equal(result.steps,14382,date);if(source!=='explicit')assert.ok(result.confidence<.8);}
assert.equal(parseOCR('Steps\nTOTAL\n83\nOctober 1, 2026').steps,83);
assert.equal(parseOCR('Steps\nTOTAL\n14\u202f382\n1. októbra 2026').steps,14382);
assert.equal(parseOCR('October 1, 2026').steps,null);
console.log('PASS 21 OCR parser checks: Apple Health date formats, small counts, ranges, ambiguity, invalid dates and no Today guessing.');
