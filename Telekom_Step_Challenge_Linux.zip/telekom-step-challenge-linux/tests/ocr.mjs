import {createWorker} from 'tesseract.js';
import assert from 'node:assert/strict';
import path from 'node:path';
const worker=await createWorker('eng',1,{langPath:path.resolve('public/ocr')});
try{const {data}=await worker.recognize('tests/step-screenshot.png');assert.match(data.text,/14,382/);assert.match(data.text,/October 1, 2026/);console.log('PASS: bundled Tesseract reads screenshot steps and date.');}finally{await worker.terminate();}
