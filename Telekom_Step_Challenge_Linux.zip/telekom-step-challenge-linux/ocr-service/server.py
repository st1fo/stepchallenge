"""Private Tesseract adapter: authenticated image bytes -> extracted text."""
import asyncio
import io
import os
import secrets
import warnings
from fastapi import FastAPI, Request, HTTPException
from starlette.concurrency import run_in_threadpool
from PIL import Image, ImageOps, ImageStat
import pytesseract

app = FastAPI(docs_url=None, redoc_url=None, openapi_url=None)
Image.MAX_IMAGE_PIXELS = 25000000
warnings.simplefilter('error', Image.DecompressionBombWarning)
slots = asyncio.Semaphore(2)

@app.get('/health')
def health():
    return {'ok': True}

def recognize(data):
    image = Image.open(io.BytesIO(data))
    if image.format not in ('PNG', 'JPEG', 'WEBP'):
        raise ValueError('Unsupported image')
    image = ImageOps.exif_transpose(image).convert('RGB')
    image.thumbnail((2400, 3000))
    image = ImageOps.autocontrast(ImageOps.grayscale(image))
    if ImageStat.Stat(image).mean[0] < 100:
        image = ImageOps.invert(image)
    available = pytesseract.get_languages()
    lang = '+'.join(x for x in ('eng', 'slk', 'deu') if x in available)
    return pytesseract.image_to_string(image, lang=lang, config='--psm 6', timeout=20)

@app.post('/ocr')
async def ocr(request: Request):
    token = os.environ.get('OCR_SERVICE_TOKEN', '')
    if not token or not secrets.compare_digest(request.headers.get('authorization', ''), 'Bearer ' + token):
        raise HTTPException(401, 'Unauthorized')
    if slots.locked():
        raise HTTPException(429, 'OCR busy')
    async with slots:
        data = bytearray()
        async for chunk in request.stream():
            data.extend(chunk)
            if len(data) > 8 * 1024 * 1024:
                raise HTTPException(413, 'Image too large')
        try:
            return {'text': await run_in_threadpool(recognize, bytes(data))}
        except Exception:
            raise HTTPException(422, 'Unable to read image')
