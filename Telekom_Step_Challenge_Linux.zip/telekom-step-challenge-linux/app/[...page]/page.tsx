import StepApp from '@/components/step-app';
export default function Page(){return <StepApp/>;}
