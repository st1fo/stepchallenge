import {db} from '@/lib/server';
export const dynamic='force-dynamic';
export async function GET(){try{await db().prepare('SELECT 1').first();return Response.json({ok:true});}catch{return Response.json({ok:false},{status:503});}}
