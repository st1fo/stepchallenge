# Telekom Step Challenge — Linux

Samostatná aplikácia pre vlastný Linux server. Aktuálne mobilné UI, bez demo účastníkov a bez závislosti od pôvodného cloudového hostingu.

**Stack:** Next.js + React + TypeScript + Tailwind, Node.js 24, SQLite, lokálne súkromné screenshoty, serverové Tesseract OCR (Python). Docker Compose spúšťa aplikáciu a OCR službu. SQLite je uložená v trvalom Docker volume; nepotrebuje samostatný databázový server. Táto edícia nepoužíva PostgreSQL a je určená pre jednu VM/jednu inštanciu aplikácie.

**Nová inštalácia začína prázdna. Existujúce účty, heslá, výsledky ani screenshoty z online verzie sa automaticky neprenesú.** Vytvorí sa len admin, októbrová výzva a definície achievementov.

## 1. VM vo vSphere

Odporúčaná počiatočná konfigurácia pre menšiu internú súťaž, nie výsledok záťažového testu:

| Nastavenie | Hodnota |
|---|---|
| OS | Ubuntu Server 24.04 LTS, 64-bit |
| CPU | 4 vCPU |
| RAM | 8 GB |
| Disk | 60 GB, sledovať voľné miesto |
| Sieť | Sieť s prístupom na internet; privátna IP postačuje pre tunel |
| Správa | OpenSSH, používateľ so sudo |

GPU netreba. Pri inštalácii sa sťahujú Docker images, npm/Python balíky a Tesseract. Na bežné serverové OCR netreba API kľúč ani externú AI službu. Používaj lokálny disk VM, nie zdieľaný NFS adresár pre SQLite. Spúšťaj iba jednu repliku aplikácie.

## 2. Docker na novej Ubuntu VM

Ak už máš funkčný Docker Engine a Compose plugin, preskoč túto časť. Na čistej Ubuntu VM:

```bash
sudo apt update
sudo apt install -y ca-certificates curl unzip python3
sudo install -m 0755 -d /etc/apt/keyrings
sudo curl -fsSL https://download.docker.com/linux/ubuntu/gpg -o /etc/apt/keyrings/docker.asc
sudo chmod a+r /etc/apt/keyrings/docker.asc
sudo tee /etc/apt/sources.list.d/docker.sources >/dev/null <<EOF
Types: deb
URIs: https://download.docker.com/linux/ubuntu
Suites: $(. /etc/os-release && echo "${UBUNTU_CODENAME:-$VERSION_CODENAME}")
Components: stable
Architectures: $(dpkg --print-architecture)
Signed-By: /etc/apt/keyrings/docker.asc
EOF
sudo apt update
sudo apt install -y docker-ce docker-ce-cli containerd.io docker-buildx-plugin docker-compose-plugin
sudo systemctl enable --now docker
sudo docker compose version
sudo docker run --rm hello-world
```

Ak už VM používa iné Docker/containerd balíky, riaď sa [oficiálnym postupom Docker](https://docs.docker.com/engine/install/ubuntu/) pre odstránenie konfliktov; neprerušuj existujúce služby naslepo. Nižšie používame `sudo`, takže netreba pridávať používateľa do skupiny docker.

## 3. Rozbalenie a prvé spustenie

Nahraj ZIP cez SCP alebo SFTP na VM a rozbaľ ho:

```bash
unzip Telekom_Step_Challenge_Linux.zip
cd telekom-step-challenge-linux
python3 scripts/setup.py --email tvoj.email@example.com --origin http://localhost:3000
sudo docker compose up -d --build
sudo docker compose ps
curl --fail http://127.0.0.1:3000/api/health
cat README-ADMIN.local.md
```

Nahraď email vlastným. Prvý build môže trvať niekoľko minút. Health endpoint má vrátiť `{"ok":true}`. Pri štarte sa automaticky aplikujú SQL migrácie a založí admin. Na hostiteľskom systéme netreba Node.js ani Python OCR knižnice.

Port je štandardne dostupný iba na `127.0.0.1` servera. Na svojom počítači otvor SSH presmerovanie (nahraď používateľa a privátnu IP VM):

```bash
ssh -N -L 3000:127.0.0.1:3000 pouzivatel@IP_TVOJEJ_VM
```

Potom na počítači otvor **http://localhost:3000**. Na telefóne použi HTTPS tunel podľa časti 6.

Pre dočasný test v dostupnej LAN môžeš pri prvom nastavení použiť:

```bash
python3 scripts/setup.py --email tvoj.email@example.com --origin http://IP_TVOJEJ_VM:3000 --bind 0.0.0.0
```

Toto je alternatíva k prvému `setup.py`, nie druhé spustenie. Skript existujúci `.env` neprepíše. V LAN musí smerovanie/firewall povoliť port 3000. HTTP je vhodné len na dôveryhodný lokálny test; pre kolegov nastav HTTPS.

## 4. Admin credentials

**Nie je žiadne spoločné predvolené heslo ani demo admin účet.**

- Admin email je hodnota `--email` z inštalácie.
- Skript vygeneruje náhodné 40-znakové admin heslo.
- Presný email, heslo aj prihlasovací odkaz nájdeš v **[README-ADMIN.local.md](README-ADMIN.local.md)**, vytvorenom pri inštalácii.
- Rovnaké počiatočné hodnoty sú v `.env` ako `ADMIN_EMAIL` a `ADMIN_PASSWORD`.
- Súbory majú prístupové práva 600. Nezverejňuj ich ani ich nepridávaj do Git repozitára.
- Účet sa vytvorí len ak daný email ešte neexistuje. Zmena `ADMIN_PASSWORD` v `.env` **nemení heslo existujúceho účtu**.

Obnova zabudnutého admin hesla z konzoly VM:

```bash
sudo docker compose exec app node scripts/admin.mjs tvoj.email@example.com
```

Príkaz vypíše nové náhodné heslo, zruší staré sessions daného admina a zapíše audit. Ulož nové heslo do svojho správcu hesiel, `.env` a súkromného `README-ADMIN.local.md`. Reset je dostupný iba operátorovi servera, nie cez verejný endpoint.

## 5. Konfigurácia `.env`

| Premenná | Význam |
|---|---|
| `APP_ORIGIN` | Presná adresa, z ktorej používatelia otvárajú aplikáciu, napr. `https://pridelena-adresa.ngrok-free.app`. Bez koncového `/`. Riadi CSRF kontrolu a Secure cookie. |
| `ADMIN_EMAIL` | Email počiatočného administrátora. |
| `ADMIN_PASSWORD` | Náhodné počiatočné heslo, min. 16 znakov; generuje setup. |
| `OCR_SERVICE_TOKEN` | Náhodné spoločné tajomstvo aplikácie a OCR; generuje setup. |
| `ALLOWED_EMAIL_DOMAIN` | Voliteľná doména povolená pri registrácii, napr. `firma.sk`, bez `@`. Prázdne = otvorená registrácia. Email sa zatiaľ neoveruje správou. |
| `BIND_IP` | `127.0.0.1` pre tunel/proxy na hostiteľovi; `0.0.0.0` pre priamy LAN prístup. |
| `PORT` | Port na hostiteľovi, štandardne `3000`. |

Compose nastavuje `DATA_DIR=/app/data` a `OCR_SERVICE_URL=http://ocr:8000/ocr` automaticky. OCR port sa na hostiteľa nepublikuje. Pri spustení bez Dockeru treba tieto dve premenné nastaviť samostatne.

Po úprave `.env` použi:

```bash
sudo docker compose up -d --force-recreate
```

Obyčajný `restart` nové premenné nenačíta. Používaj jednu kanonickú adresu. Ak `APP_ORIGIN` nastavíš na verejné HTTPS, prihlasuj sa cez túto adresu, nie cez HTTP IP; inak sa zamietne zápis alebo prehliadač neodošle Secure cookie. Health endpoint zostáva dostupný lokálne.

## 6. Verejný link bez verejnej IP a bez vlastnej domény

Pre študentskú VM môžeš použiť **ngrok** s pridelenou doménou. Vytvorenie účtu, token a spustenie tunela musíš dokončiť na VM. Použi spôsob sprístupnenia povolený správcom vašej siete.

1. Vytvor si účet na [ngrok](https://ngrok.com/) a skopíruj pridelenú dev doménu z dashboardu. Free plán má limity a môže návštevníkovi najprv ukázať stránku „Visit“; nie je to garantovaný firemný hosting.
2. Nainštaluj Linux agenta podľa [oficiálneho návodu](https://ngrok.com/download/linux).
3. Vytvor súkromný konfiguračný súbor:

```bash
sudo install -m 600 /dev/null /etc/ngrok-step.yml
sudo nano /etc/ngrok-step.yml
```

Do súboru vlož a nahraď token aj doménu:

```yaml
version: 3
agent:
  authtoken: TVOJ_NGROK_TOKEN
endpoints:
  - name: step-challenge
    url: https://TVOJA_PRIDELENA_DOMENA.ngrok-free.app
    upstream:
      url: http://127.0.0.1:3000
```

4. V projektovom `.env` nastav **rovnakú** adresu:

```dotenv
APP_ORIGIN=https://TVOJA_PRIDELENA_DOMENA.ngrok-free.app
BIND_IP=127.0.0.1
```

5. Aplikáciu znovu vytvor a tunel najprv otestuj:

```bash
sudo docker compose up -d --force-recreate
sudo ngrok start step-challenge --config /etc/ngrok-step.yml
```

Otvor verejnú HTTPS adresu na telefóne. Keď funguje, ukonči testovací ngrok proces cez Ctrl+C a nainštaluj ho ako službu:

```bash
sudo ngrok service install --config /etc/ngrok-step.yml
sudo ngrok service start
sudo systemctl status ngrok
```

Docker aplikácia aj tunel tak môžu bežať po odhlásení SSH a reštarte VM. Verejná IP ani port forwarding nie sú potrebné, ale sieť musí povoľovať odchádzajúce spojenie tunela. Ak je ngrok blokovaný, použi schválený firemný reverse proxy/VPN gateway.

Na krátky test existuje tiež [Cloudflare Quick Tunnel](https://developers.cloudflare.com/tunnel/get-started/quick-tunnels/) s náhodným `trycloudflare.com` odkazom. Ten je dočasný; pri zmene odkazu musíš upraviť `APP_ORIGIN`. Pre celú súťaž používaj stabilnú adresu.

Zdroje nastavení tunela: [ngrok config v3](https://ngrok.com/docs/gateway/agent/config/v3), [služba agenta](https://ngrok.com/docs/gateway/agent/cli), [Free limity](https://ngrok.com/docs/pricing-limits/free-plan-limits).

## 7. Dáta, zálohy a aktualizácie

Databáza a screenshoty sú vo volume `telekom-step-challenge_challenge-data`:

- `/app/data/challenge.sqlite` a SQLite WAL súbory,
- `/app/data/screenshots/` s náhodnými názvami.

Screenshoty sa nikdy neservujú priamo ako statické súbory. API kontroluje vlastníka/admina. SQL migrácie sú v `drizzle/*.sql`, aplikované raz pri štarte; tabuľka `schema_migrations` zaznamenáva vykonané migrácie.

**Záloha:**

```bash
sudo bash scripts/backup.sh
```

Skript na chvíľu zastaví aplikáciu, zálohuje celý dátový adresár a opäť ju spustí. ZIP projektu nie je záloha používateľských dát. Archív v `backups/` skopíruj aj mimo VM. Samostatne bezpečne zálohuj `.env` a konfiguráciu tunela. Zálohy obsahujú osobné údaje aj screenshoty.

**Obnova zo zálohy:**

```bash
sudo bash scripts/restore.sh backups/backup-TIMESTAMP.tar.gz
```

Obnova vyžiada napísanie `RESTORE` a nahradí aktuálne dáta. Používaj len dôveryhodné archívy vytvorené backup skriptom. Pri obnove musí existovať `.env` a zostavený Docker image. Prístupové údaje sa obnovia podľa databázy v zálohe.

**Bežné príkazy:**

```bash
sudo docker compose logs --tail=100 app ocr
sudo docker compose ps
sudo docker compose restart
sudo docker compose stop
sudo docker compose up -d
```

Pri aktualizácii najprv zálohuj, nahraď zdrojový kód, zachovaj `.env` a volume, potom `sudo docker compose up -d --build`. **Nepoužívaj `docker compose down -v`: odstráni aj dáta.** Novú verziu najprv over na kópii zálohy; návrat na starý kód nemusí byť kompatibilný s novšou migráciou.

## 8. Čo je implementované

- Registrácia, prihlásenie a odhlásenie; serverové sessions v databáze, HttpOnly/SameSite cookie, Secure cez HTTPS; PBKDF2-SHA256 so soľou a 600 000 iteráciami.
- Dashboard/leaderboard z reálnych overených záznamov, top 3, profil, história, graf, streak a achievementy.
- Mobilné rozloženie zachované; spodná navigácia nemá duplicitný Leaderboard.
- Upload PNG/JPEG/WebP do 8 MB, kontrola skutočného formátu a rozmerov, limit tela requestu.
- Serverové OCR Tesseract vrátane svetlého/tmavého obrázka; detekcia dátumu a počtu krokov. OCR je oddelená služba.
- Podpora viacerých zápisov dátumu vrátane slovenských/anglických/nemeckých mesiacov. Nejednoznačný dátum alebo chýbajúci rok sa nepovažuje za spoľahlivý dôkaz.
- Používateľ vždy potvrdzuje výsledok. Opravené alebo nedôveryhodné hodnoty čakajú na admin review; nepočítajú sa automaticky do poradia.
- Pri výpadku serverového OCR môže UI použiť lokálne browser OCR alebo manuálny vstup; backend také záznamy označí na kontrolu.
- SHA-256 kontrola identického screenshotu, UNIQUE(user_id, date), UNIQUE(upload_id), kontrola intervalu výzvy, pozitívnych celých krokov a vysokých hodnôt.
- Admin kontrola screenshotov, schválenie, zamietnutie, úprava s dôvodom a audit log; poradovník sa prepočíta.
- Screenshoty vidí len vlastník a admin. Admin ich po skončení výzvy môže odstrániť a ponechať výsledky.
- CSRF kontrola presnej adresy, serverová autorizácia, obmedzenie pokusov o prihlásenie a uploadov, bezpečnostné HTTP hlavičky.
- Automatická inicializácia databázy, Docker healthchecks, trvalý volume, opätovné spustenie po reštarte, skripty na zálohu a obnovu.

Začiatočná výzva: **October Step Challenge, 1.–31. 10. 2026, limit na kontrolu 60 000 krokov/deň**. Hodnoty výzvy sú v tabuľke `challenges`, nie natvrdo v validácii. UI na správu ďalších výziev nie je súčasťou MVP; zmenu dátumov/názvu nastavuje operátor v databáze po zálohe. Záznamy mimo intervalu sa nezapočítajú.

## 9. Obmedzenia a externé veci

- Treba tvoju Linux VM, Docker, zálohovacie miesto a prípadne účet/token tunela alebo firemný HTTPS proxy.
- SSO, emailové overenie, emailový reset hesla, SMTP a firemné object storage zatiaľ nie sú integrované.
- Obmedzenie registrácie podľa domény emailu nie je overenie identity zamestnanca. Na skutočne uzavretý firemný prístup doplň schválenú prístupovú bránu alebo SSO.
- Screenshoty možno upraviť. OCR ani hash nedokazujú fyzicky prejdené kroky. Ide o primeranú kontrolu priateľskej súťaže.
- Apple Health musí na screenshote obsahovať čitateľný denný dátum; „Today/Dnes“, rozsah dátumov alebo orezaný dátum sa nehádajú. Taký záznam musí skontrolovať admin.
- HEIC nie je podporovaný; použi PNG/JPEG screenshot.
- SQLite je vhodná pre jednu menšiu inštanciu. Viac replík/veľká záťaž si vyžiada PostgreSQL a zdieľané úložisko. Kapacita nebola záťažovo zmeraná.
- Nie je tu automatické škálovanie, monitoring ani automatické off-site zálohovanie.

## 10. Štruktúra projektu

| Cesta | Obsah |
|---|---|
| `app/` | Stránky Next.js a API `/api/*` |
| `components/step-app.tsx` | Zachované používateľské a admin UI |
| `lib/server.ts` | Autentifikácia, validácia, poradie, CSRF a rate limiting |
| `lib/database.ts` | SQLite adaptér a migrácie |
| `lib/storage.ts` | Súkromné súborové úložisko; vymeniteľný adaptér |
| `lib/ocr.ts`, `lib/browser-ocr.ts` | Parser výsledkov a browser fallback |
| `lib/seed.ts` | Výzva, achievementy a počiatočný admin; bez demo dát |
| `drizzle/` | SQL schéma/migrácie |
| `ocr-service/` | Python API a Tesseract Docker image |
| `scripts/` | Inštalácia, admin reset, build, záloha a obnova |
| `tests/` | Integračné a OCR testy, syntetický screenshot |
| `Dockerfile`, `compose.yaml` | Produkčný Node runtime a OCR služba |

## 11. Testovanie a overenie

Pred zabalením prešlo:

- čisté `npm ci` z priloženého lockfile,
- produkčný Next.js build s TypeScript kontrolou,
- 21 testov OCR parsera,
- 49 integračných kontrol cez skutočný produkčný Node server, SQLite súborové úložisko a Tesseract: registrácia, login, OCR, uloženie, poradie, duplicity, opravy/reject admina, súkromie, CSRF, routy a zachovanie dát po reštarte.

**Docker daemon v testovacom prostredí nie je dostupný. Docker images, Compose štart a Docker záloha/obnova preto neboli vykonané end-to-end.** Rovnaký produkčný standalone server a OCR služba boli otestované mimo kontajnerov. Finálne overenie na tvojej Ubuntu VM: `docker compose ps`, health endpoint, login, skutočný screenshot z telefónu a skúšobná záloha. Mobilné UI je prevzaté z funkčnej verzie; nová vizuálna kontrola na fyzickom telefóne sa tu nevykonala.

Pre opakovanie testov mimo Dockeru (Node.js 24, Python 3.12+):

```bash
sudo apt install -y python3-venv tesseract-ocr tesseract-ocr-slk tesseract-ocr-deu
python3 -m venv .venv
.venv/bin/pip install -r ocr-service/requirements.txt
npm ci
npm run build
OCR_PYTHON="$PWD/.venv/bin/python" npm test
```

Testy používajú dočasnú databázu a náhodné credentials, nie produkčné dáta. Porty 3107 a 8107 musia byť voľné.

## 12. Rýchle riešenie problémov

| Problém | Čo skontrolovať |
|---|---|
| „Please refresh the page…“ pri prihlásení | `APP_ORIGIN` musí byť presne adresa v prehliadači; po zmene recreate kontajnerov. |
| Po login sa vracia login | Nemiešaj HTTPS verejnú adresu s HTTP IP; cookie sa viaže na hostiteľa. |
| OCR nič neprečíta | `docker compose logs ocr`, čitateľný celý dátum a kroky, PNG/JPEG; manuálny vstup ide na admin kontrolu. |
| Kroky sa neobjavili v poradí | Skontroluj status `pending_review`; admin ich musí schváliť. |
| Telefón neotvorí privátnu IP | Telefón musí mať smerovanie do LAN/VPN, alebo použi verejný HTTPS tunel. |
| ngrok adresa nefunguje | Agent/služba beží, token a pridelená doména sú správne, účet nemá vyčerpaný limit a sieť povoľuje odchádzajúce spojenie. |
| Aplikácia je unhealthy | `sudo docker compose logs --tail=100 app ocr`; skontroluj `.env`, disk a oprávnenia volume. |
| Zabudnuté admin heslo | Použi konzolový reset z časti 4. |
