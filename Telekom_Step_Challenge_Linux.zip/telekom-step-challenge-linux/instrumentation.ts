export async function register(){
 if(process.env.NEXT_RUNTIME==='nodejs'){
  const origin=process.env.APP_ORIGIN;
  if(!origin||new URL(origin).origin!==origin)throw new Error('Set APP_ORIGIN to the exact external origin, without trailing slash.');
  if(!process.env.ADMIN_EMAIL||!process.env.ADMIN_PASSWORD||process.env.ADMIN_PASSWORD.length<16)throw new Error('Run scripts/setup.py to configure administrator credentials.');
  const {seed}=await import('./lib/seed');await seed();
 }
}
