import {DatabaseSync, type SQLInputValue} from 'node:sqlite';
import {mkdirSync,readFileSync,readdirSync} from 'node:fs';
import path from 'node:path';

// Single Node process, SQLite WAL, durable Docker volume. No cloud bindings.
class Statement {
 constructor(private database:DatabaseSync,private sql:string,private values:SQLInputValue[]=[]){ }
 bind(...values:SQLInputValue[]){return new Statement(this.database,this.sql,values);}
 async first<T=Record<string,unknown>>():Promise<T|null>{return (this.database.prepare(this.sql).get(...this.values) as T)??null;}
 async all<T=Record<string,unknown>>(){return {results:this.database.prepare(this.sql).all(...this.values) as T[]};}
 runSync(){const result=this.database.prepare(this.sql).run(...this.values);return {success:true,meta:{changes:Number(result.changes)}};}
 async run(){return this.runSync();}
}
let singleton:ReturnType<typeof connect>|undefined;
function connect(){
 const directory=path.resolve(process.env.DATA_DIR||'data');mkdirSync(directory,{recursive:true,mode:0o700});
 const raw=new DatabaseSync(path.join(directory,'challenge.sqlite'));
 raw.exec('PRAGMA foreign_keys=ON; PRAGMA journal_mode=WAL; PRAGMA synchronous=FULL; PRAGMA busy_timeout=5000;');
 raw.exec('CREATE TABLE IF NOT EXISTS schema_migrations(name TEXT PRIMARY KEY, applied_at TEXT NOT NULL)');
 const migrations=path.resolve('drizzle');
 for(const name of readdirSync(migrations).filter(n=>n.endsWith('.sql')).sort()){
  if(raw.prepare('SELECT name FROM schema_migrations WHERE name=?').get(name))continue;
  raw.exec('BEGIN IMMEDIATE');try{raw.exec(readFileSync(path.join(migrations,name),'utf8'));raw.prepare('INSERT INTO schema_migrations VALUES(?,?)').run(name,new Date().toISOString());raw.exec('COMMIT');}catch(e){raw.exec('ROLLBACK');throw e;}
 }
 raw.prepare('DELETE FROM sessions WHERE expires_at<?').run(Date.now());
 raw.prepare('DELETE FROM rate_limits WHERE expires_at<?').run(Date.now());
 return {prepare:(sql:string)=>new Statement(raw,sql),async batch(statements:Statement[]){raw.exec('BEGIN IMMEDIATE');try{const results=statements.map(s=>s.runSync());raw.exec('COMMIT');return results;}catch(e){raw.exec('ROLLBACK');throw e;}}};
}
export function database(){return singleton??=connect();}
