import {db,bindings,passwordHash,id,now} from './server';
export async function seed(){
 await db().prepare('INSERT OR IGNORE INTO challenges VALUES(?,?,?,?,?,?)').bind('october-2026','October Step Challenge','2026-10-01','2026-10-31','active',60000).run();
 for(const [key,name,description] of [['10k','First 10K day','Walk 10,000 steps in a day'],['20k','20K day','Walk 20,000 steps in a day'],['50k','50K club','Reach 50,000 total steps'],['100k','100K club','Reach 100,000 total steps'],['250k','250K club','Reach 250,000 total steps'],['streak7','On a roll','Submit 7 consecutive days']])await db().prepare('INSERT OR IGNORE INTO achievements VALUES(?,?,?)').bind(key,name,description).run();
 const email=bindings().ADMIN_EMAIL?.trim().toLowerCase(),p=bindings().ADMIN_PASSWORD;
 if(email&&p&&!await db().prepare('SELECT id FROM users WHERE email=?').bind(email).first()){
  if(p.length<16)throw new Error('Admin password must contain at least 16 characters');
  await db().prepare('INSERT OR IGNORE INTO users VALUES(?,?,?,?,?,?,?)').bind(id(),'Challenge Admin',email,await passwordHash(p),now(),1,0).run();
 }
}
