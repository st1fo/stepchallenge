import {parseOCR} from './ocr';
/** Preprocess pixels only; never synthesize a date or trust image metadata. */
async function prepare(file:File,headerOnly=false):Promise<Blob>{
 const url=URL.createObjectURL(file);const image=new Image();try{await new Promise<void>((resolve,reject)=>{image.onload=()=>resolve();image.onerror=reject;image.src=url;});const cropH=headerOnly?Math.round(image.naturalHeight*.58):image.naturalHeight;const scale=Math.min(2,1600/image.naturalWidth,3200/cropH);const canvas=document.createElement('canvas');canvas.width=Math.round(image.naturalWidth*scale);canvas.height=Math.round(cropH*scale);const ctx=canvas.getContext('2d',{willReadFrequently:true});if(!ctx)throw Error('Image processing unavailable');ctx.drawImage(image,0,0,image.naturalWidth,cropH,0,0,canvas.width,canvas.height);const pixels=ctx.getImageData(0,0,canvas.width,canvas.height);let sum=0;for(let i=0;i<pixels.data.length;i+=16)sum+=(pixels.data[i]+pixels.data[i+1]+pixels.data[i+2])/3;const dark=sum/(pixels.data.length/16)<110;for(let i=0;i<pixels.data.length;i+=4){let v=pixels.data[i]*.299+pixels.data[i+1]*.587+pixels.data[i+2]*.114;if(dark)v=255-v;pixels.data[i]=pixels.data[i+1]=pixels.data[i+2]=v;}ctx.putImageData(pixels,0,0);return await new Promise<Blob>((resolve,reject)=>canvas.toBlob(b=>b?resolve(b):reject(Error('Image processing failed')),'image/png'));}finally{URL.revokeObjectURL(url);}
}
export async function readScreenshot(file:File,year:number,onProgress:(s:string)=>void){
 const {createWorker,PSM}=await import('tesseract.js');const worker=await createWorker('eng',1,{workerPath:'/ocr/worker.min.js',corePath:'/ocr',langPath:'/ocr',logger:m=>{if(m.status==='recognizing text')onProgress(`Reading screenshot · ${Math.round(m.progress*100)}%`);}});
 try{await worker.setParameters({tessedit_pageseg_mode:PSM.SPARSE_TEXT});const result=await worker.recognize(await prepare(file));let parsed=parseOCR(result.data.text,year);
  if(!parsed.date&&parsed.dateSource!=='ambiguous'){onProgress('Taking a closer look at the date…');await worker.setParameters({tessedit_pageseg_mode:PSM.AUTO});const header=await worker.recognize(await prepare(file,true));const merged=parseOCR(result.data.text+'\n'+header.data.text,year);parsed={...merged,steps:parsed.steps??merged.steps};}
  return parsed;
 }finally{await worker.terminate();}
}
