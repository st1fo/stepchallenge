export type OCRResult={steps:number|null;date:string|null;confidence:number;dateSource:'explicit'|'inferred_year'|'missing'|'ambiguous'};
const normalize=(s:string)=>s.normalize('NFD').replace(/[\u0300-\u036f]/g,'').toLowerCase().replace(/[\u00a0\u202f]/g,' ');
const monthGroups=[['jan','january','januar','januara','leden','ledna'],['feb','february','februar','februara','unor','unora'],['mar','march','marec','marca','marz','brezen','brezna'],['apr','april','aprila','duben','dubna'],['may','maj','maja','kveten','kvetna','mai'],['jun','june','juna','cerven','cervna','juni'],['jul','july','jula','cervenec','cervence','juli'],['aug','august','augusta','srpen','srpna'],['sep','sept','september','septembra','zari'],['oct','october','okt','oktober','oktobra','rijen','rijna'],['nov','november','novembra','listopad','listopadu'],['dec','december','decembra','pro','prosinec','prosince','dez','dezember']];
/** No clock-based guesses: Today/Yesterday and date ranges never establish a daily date. */
export function parseOCR(raw:string,year=2026):OCRResult{
 const text=normalize(raw);const found=new Map<string,boolean>();let range=false;
 const add=(y:number,m:number,d:number,explicit:boolean)=>{if(y<2000||y>2100||m<1||m>12||d<1||d>31)return;const date=`${y}-${String(m).padStart(2,'0')}-${String(d).padStart(2,'0')}`;if(new Date(date+'T00:00:00Z').toISOString().slice(0,10)!==date)return;found.set(date,(found.get(date)||false)||explicit);};
 const dateLines=new Set<number>();const lines=text.split('\n').map(x=>x.trim()).filter(Boolean);
 lines.forEach((line,i)=>{const before=found.size;
  if(/\d\s*[-–—]\s*\d/.test(line.replace(/\b20\d{2}-\d{2}-\d{2}\b/g,'')))range=true;
  for(const m of line.matchAll(/\b(20\d{2})-(\d{1,2})-(\d{1,2})\b/g))add(+m[1],+m[2],+m[3],true);
  for(const m of line.matchAll(/\b(\d{1,2})\s*\.\s*(\d{1,2})\s*\.(?:\s*(20\d{2}))?/g))add(m[3]?+m[3]:year,+m[2],+m[1],!!m[3]);
  // Slash dates require an unambiguous day/month order. 10/01 is deliberately not guessed.
  for(const m of line.matchAll(/\b(\d{1,2})\/(\d{1,2})\/(20\d{2})\b/g)){if(+m[1]>12)add(+m[3],+m[2],+m[1],true);else if(+m[2]>12)add(+m[3],+m[1],+m[2],true);}
  monthGroups.forEach((aliases,index)=>{const month=`(?:${aliases.slice().sort((a,b)=>b.length-a.length).join('|')})\\.?`;
   const dayFirst=new RegExp(`\\b(\\d{1,2})\\.?\\s*${month}(?![a-z])(?:[, ]+\\s*(20\\d{2}))?`,'g');
   const monthFirst=new RegExp(`\\b${month}\\s+(\\d{1,2})(?!\\d)(?:[, ]+\\s*(20\\d{2}))?`,'g');
   for(const pattern of [dayFirst,monthFirst])for(const m of line.matchAll(pattern))add(m[2]?+m[2]:year,index+1,+m[1],!!m[2]);
  });
  if(found.size>before||/\b20\d{2}\b|\b\d{1,2}[.:/]\d{1,2}/.test(line)||monthGroups.some(ms=>ms.some(m=>new RegExp(`\\b${m}\\b`).test(line))))dateLines.add(i);
 });
 const candidates:{n:number;score:number}[]=[];
 const label=/steps|krok|schritte|pas\b/;const total=/total|celkom|celkem|gesamt|sucet/;
 lines.forEach((line,i)=>{if(dateLines.has(i)||/\d[:/]\d|\b(?:kcal|bpm|km|miles|floors|average|priemer|prumer)\b/.test(line))return;
  const nums=line.match(/\b\d{1,3}(?:[,. ]\d{3})+\b|\b\d{1,6}\b/g)||[];
  for(const n of nums){const v=Number(n.replace(/[^0-9]/g,''));const near=lines.slice(Math.max(0,i-2),i+3).join(' ');const score=label.test(line)?5:label.test(near)&&total.test(near)?4:label.test(near)?3:total.test(near)?2:0;if(v>0&&v<=1000000&&(score>=2||v>=1000))candidates.push({n:v,score});}
 });
 candidates.sort((a,b)=>b.score-a.score||b.n-a.n);const steps=candidates[0]?.n||null;
 const ambiguous=range||found.size>1;const date=ambiguous||found.size!==1?null:[...found.keys()][0];
 const dateSource=ambiguous?'ambiguous':date?(found.get(date)?'explicit':'inferred_year'):'missing';
 return {steps,date,dateSource,confidence:steps&&date&&candidates[0]?.score>=3?(dateSource==='explicit'?.9:.65):steps?.4:0};
}
