import {mkdir,writeFile,readFile,unlink} from 'node:fs/promises';
import path from 'node:path';
const root=()=>path.resolve(process.env.DATA_DIR||'data','screenshots');
function location(key:string){if(!/^[a-f0-9-]{36}$/.test(key))throw new Error('Invalid storage key');return path.join(root(),key);}
/** Private filesystem adapter. Access is always authorized by the API first. */
export const screenshotStorage={
 async put(key:string,bytes:ArrayBuffer,_mime:string){await mkdir(root(),{recursive:true,mode:0o700});await writeFile(location(key),new Uint8Array(bytes),{mode:0o600,flag:'wx'});},
 async get(key:string){try{return {body:new Uint8Array(await readFile(location(key)))};}catch(e:any){if(e.code==='ENOENT')return null;throw e;}},
 async delete(key:string){try{await unlink(location(key));}catch(e:any){if(e.code!=='ENOENT')throw e;}},
};
