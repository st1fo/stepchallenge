#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/.."
archive="${1:?Usage: bash scripts/restore.sh backups/backup-TIMESTAMP.tar.gz}"
test -f "$archive"
tar -tzf "$archive" >/dev/null
printf 'This replaces the current database and screenshots. Type RESTORE: '
read -r confirmation
[ "$confirmation" = RESTORE ] || exit 1
docker compose stop app
# Only restore trusted archives produced by backup.sh.
docker compose run --rm --no-deps -T --user root --entrypoint sh app -c 'find /app/data -mindepth 1 -delete && tar -xzf - -C /app/data && chown -R node:node /app/data' < "$archive"
docker compose start app
