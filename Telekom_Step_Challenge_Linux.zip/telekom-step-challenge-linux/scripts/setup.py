#!/usr/bin/env python3
"""Generate private installation credentials. Never overwrites an existing .env."""
import argparse, os, re, secrets
from pathlib import Path
from urllib.parse import urlsplit
root=Path(__file__).resolve().parent.parent
parser=argparse.ArgumentParser()
parser.add_argument('--origin', default='http://localhost:3000')
parser.add_argument('--email', required=True)
parser.add_argument('--bind', default='127.0.0.1', choices=['127.0.0.1','0.0.0.0'])
args=parser.parse_args()
u=urlsplit(args.origin)
if u.scheme not in ('http','https') or not u.hostname or u.username or u.password or u.path or u.query or u.fragment or any(c.isspace() for c in args.origin):
 parser.error('--origin must be http(s)://host[:port] without a trailing slash')
if not re.fullmatch(r'[a-zA-Z0-9._+%-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}',args.email):parser.error('Invalid admin email')
if (root/'.env').exists():parser.error('.env already exists; edit it manually. Existing credentials were not changed.')
os.umask(0o077)
password=secrets.token_hex(20)
token=secrets.token_hex(32)
with (root/'.env').open('x') as f:
 f.write(f'APP_ORIGIN={args.origin}\nADMIN_EMAIL={args.email.lower()}\nADMIN_PASSWORD={password}\nOCR_SERVICE_TOKEN={token}\nALLOWED_EMAIL_DOMAIN=\nBIND_IP={args.bind}\nPORT=3000\n')
(root/'README-ADMIN.local.md').write_text(f"# Súkromné admin credentials\n\nURL: {args.origin}/login\n\nEmail: `{args.email.lower()}`\n\nHeslo: `{password}`\n\nTento súbor a .env nezverejňuj. Heslo je jedinečné pre túto inštaláciu.\nPo zmene hesla aktualizuj túto poznámku.\n")
print('Created .env and README-ADMIN.local.md (private, mode 600).')
print('Administrator credentials: cat README-ADMIN.local.md')
print('Start: docker compose up -d --build')
