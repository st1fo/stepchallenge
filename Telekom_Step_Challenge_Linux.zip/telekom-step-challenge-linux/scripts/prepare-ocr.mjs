import {createRequire} from 'node:module';
import {cp,mkdir,readdir} from 'node:fs/promises';
import path from 'node:path';
const req=createRequire(import.meta.url),root=path.resolve('public/ocr');await mkdir(root,{recursive:true});
const pkg=path.dirname(req.resolve('tesseract.js/package.json'));await cp(path.join(pkg,'dist/worker.min.js'),path.join(root,'worker.min.js'));
const core=path.dirname(createRequire(path.join(pkg,'package.json')).resolve('tesseract.js-core/package.json'));
for(const f of await readdir(core))if(f.endsWith('.wasm.js'))await cp(path.join(core,f),path.join(root,f));
const lang=path.dirname(req.resolve('@tesseract.js-data/eng/package.json'));await cp(path.join(lang,'4.0.0/eng.traineddata.gz'),path.join(root,'eng.traineddata.gz'));
console.log('Self-hosted OCR assets ready.');
