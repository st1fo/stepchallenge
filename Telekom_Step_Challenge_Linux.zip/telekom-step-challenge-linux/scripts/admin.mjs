import {DatabaseSync} from 'node:sqlite';
import {randomBytes,pbkdf2Sync} from 'node:crypto';
import path from 'node:path';
// Local root/Docker operator only; no public password reset endpoint.
const email=process.argv[2]?.trim().toLowerCase();
if(!email){console.error('Usage: node scripts/admin.mjs admin@example.com');process.exit(1);}
const db=new DatabaseSync(path.join(process.env.DATA_DIR||'data','challenge.sqlite'));
db.exec('PRAGMA foreign_keys=ON; PRAGMA busy_timeout=5000');
const user=db.prepare('SELECT id FROM users WHERE email=? AND is_admin=1').get(email);
if(!user){console.error('Administrator account not found.');process.exit(1);}
const password=randomBytes(20).toString('hex'),salt=crypto.randomUUID();
const hash=salt+':'+pbkdf2Sync(password,salt,600000,32,'sha256').toString('hex');
db.exec('BEGIN IMMEDIATE');
try{db.prepare('UPDATE users SET password_hash=? WHERE id=?').run(hash,user.id);db.prepare('DELETE FROM sessions WHERE user_id=?').run(user.id);db.prepare('INSERT INTO audit_logs VALUES(?,?,?,?,?,?,?)').run(crypto.randomUUID(),user.id,'admin_password_reset',user.id,null,null,new Date().toISOString());db.exec('COMMIT');}catch(e){db.exec('ROLLBACK');throw e;}
console.log('New administrator password: '+password);
console.log('All previous sessions for this administrator were revoked.');
