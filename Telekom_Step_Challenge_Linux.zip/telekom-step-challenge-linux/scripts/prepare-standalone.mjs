import {cp,mkdir} from 'node:fs/promises';
await mkdir('.next/standalone/.next',{recursive:true});
for(const [from,to] of [['public','.next/standalone/public'],['drizzle','.next/standalone/drizzle'],['.next/static','.next/standalone/.next/static']])await cp(from,to,{recursive:true});
