#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/.."
umask 077
mkdir -p backups
archive="backup-$(date -u +%Y%m%dT%H%M%SZ).tar.gz"
# Stop the writer so SQLite and screenshot files form one consistent snapshot.
docker compose stop app
trap 'docker compose start app >/dev/null' EXIT
docker compose run --rm --no-deps -T --user root --entrypoint tar app -C /app/data -czf - . > "backups/$archive"
test -s "backups/$archive"
tar -tzf "backups/$archive" >/dev/null
printf 'Backup created: backups/%s\n' "$archive"
